# Word Frequency Counter
## Java Program

How to run the program

- open the code with your favourite IDE
- Run WordFrequencyCounterApp.java
- Goto console
- Enter the sentence whose word frequency needs to be counted
- See the result in console

## Note

- Use JDK version 8 or above